#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Twist.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <mavros_msgs/State.h>
#include <fcntl.h>
#include <math.h>

mavros_msgs::State current_state;
mavros_msgs::SetMode land_set_mode;

geometry_msgs::PoseStamped local_pose;
geometry_msgs::TwistStamped local_vel;

geometry_msgs::PoseStamped pose;
geometry_msgs::Twist vel, vel_;

void state_cb(const mavros_msgs::State::ConstPtr& msg) {
    current_state = *msg;
}

void local_vel_cb(const geometry_msgs::TwistStamped::ConstPtr& msg){
    local_vel = *msg;
}

void local_pose_cb(const geometry_msgs::PoseStamped::ConstPtr& msg){
    local_pose = *msg;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "offb_main");
    ros::NodeHandle nh;

    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>
                 ("/mavros/setpoint_position/local", 100);
    ros::Publisher local_vel_pub = nh.advertise<geometry_msgs::Twist>
                 ("/mavros/setpoint_velocity/cmd_vel_unstamped", 100);

    ros::Subscriber local_pose_sub = nh.subscribe<geometry_msgs::PoseStamped>
                 ("/mavros/local_position/pose", 100, local_pose_cb);
    ros::Subscriber local_vel_sub = nh.subscribe<geometry_msgs::TwistStamped>               
                 ("/mavros/local_position/velocity", 100, local_vel_cb);

    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>
            ("mavros/state", 100, state_cb);

    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>
            ("mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>
            ("mavros/set_mode");

    //the setpoint publishing rate MUST be faster than 2Hz
    ros::Rate rate(20.0);

    // wait for FCU connection
    while(ros::ok() && !current_state.connected){
        ros::spinOnce();
        rate.sleep();
    }



    //send a few setpoints before starting
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(pose);
        ros::spinOnce();
        rate.sleep();
    }

    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time init_time;
    ros::Time last_request = ros::Time::now();
    int count = 1;

   while(ros::ok() && !current_state.connected){
      ros::spinOnce();
      rate.sleep();
}

bool drone_armed = false;
for (; ros::ok() && !drone_armed; ) {
    if (!current_state.connected) {
        ros::spinOnce();
        rate.sleep();
        continue; // 等待直到无人机连接
    }

    if (current_state.mode != "OFFBOARD" && (ros::Time::now() - last_request > ros::Duration(5.0))) {
        ROS_WARN_STREAM("等待进入OFFBOARD模式......");
        last_request = ros::Time::now();
    } else {
        if (!current_state.armed && (ros::Time::now() - last_request > ros::Duration(5.0))) {
            if (arming_client.call(arm_cmd) && arm_cmd.response.success) {
                ROS_WARN_STREAM("无人机解锁成功");
                break;
            }
            last_request = ros::Time::now();
        }
    }

    local_pos_pub.publish(pose);
    ros::spinOnce();
    rate.sleep();
}


while(ros::ok()){
           if (count<100){
           if (count == 1) {
               ROS_INFO_STREAM("take off");
           }
               ROS_INFO_STREAM("x=0,y=0,z=1.8");
           pose.pose.position.x = 0.0;
           pose.pose.position.y = 0.0;
           pose.pose.position.z = 1.8;
        }
        else if (count<200){
           if (count == 100) {
               ROS_INFO_STREAM("Move"); 
           }
               ROS_INFO_STREAM("x=1.0,y=0,z=1.8");
           pose.pose.position.x = 1.0;
           pose.pose.position.y = 0.0;
           pose.pose.position.z = 1.8;
        }
        else if (count<300){
           if (count == 200) {
               ROS_INFO_STREAM("Move"); 
           }
               ROS_INFO_STREAM("x=1.0,y=1,z=1.8");
           pose.pose.position.x = 1.0;
           pose.pose.position.y = 1.0;
           pose.pose.position.z = 1.8;
        }
        else if (count<400){
           if (count == 300) {
               ROS_INFO_STREAM("Move"); 
           }
               ROS_INFO_STREAM("x=1.0,y=1,z=1.5");
           pose.pose.position.x = 1.0;
           pose.pose.position.y = 1.0;
           pose.pose.position.z = 1.5;
        }
        else if (count<500){
           if (count == 400) {
               ROS_INFO_STREAM("move"); 
           }
               ROS_INFO_STREAM("x=0.0,y=1,z=1.5");
           pose.pose.position.x = 0.0;
           pose.pose.position.y = 1.0;
           pose.pose.position.z = 1.5;
      }

              else if (count<600){
           if (count == 500) {
               ROS_INFO_STREAM("move"); 
           }
               ROS_INFO_STREAM("x=0.0,y=0.0,z=1.5");
           pose.pose.position.x = 0.0;
           pose.pose.position.y = 0.0;
           pose.pose.position.z = 1.5;
      }
              else if (count<700){
           if (count == 600) {
               ROS_INFO_STREAM("move"); 
           }
               ROS_INFO_STREAM("x=0,y=0,z=1.5");
           pose.pose.position.x = 0;
           pose.pose.position.y = 0;
           pose.pose.position.z = 1.5;
      }

        else if (count<1600){
           if (count == 1500) {
               ROS_INFO_STREAM("landing"); 
           }
           land_set_mode.request.custom_mode="AUTO.LAND";
           set_mode_client.call(land_set_mode);
               ROS_INFO_STREAM("finish");
      }
	    else{
	        count=0;
        }

        if ((count+1)%100 == 0){
            std::cout<<count<<std::endl;
            ROS_INFO_STREAM("Waiting for 1 second");
            init_time = ros::Time::now();
            std::cout<<"count"<<std::endl;
            while(ros::Time::now() - init_time < ros::Duration(1.0)) {
                   local_pos_pub.publish(pose);
            }
        } else {
                   local_pos_pub.publish(pose);
        }

         local_pos_pub.publish(pose);
         ros::spinOnce();
         rate.sleep();
         count++;
}

        return 0;
}
